# -*- coding: utf-8 -*-
from .modulo import configurar_login_2fa