# login2fa

**Login 2FA modular com NiceGUI, ntfy e cookies de sessão.**

Este pacote permite adicionar login com dupla autenticação via token enviado por ntfy, com cookies persistentes de 12h.

## Instalação

```bash
pip install -e .
```

## Configuração mínima

```python
from login2fa import configurar_login_2fa

configurar_login_2fa({
    'db': {...},
    'ntfy': {...},
    'rota_sucesso': '/painel',
    'titulo_login': 'Acesso Seguro'
})
```

## Exemplo

Ver ficheiro `exemplo.py`.
